/*
 *  ModelLoader.cpp
 *
 *  Created on: 2014/11/12
 *      Author: Dimitri Kourkoulis
 *     License: BSD 3-Clause License (see LICENSE file)
 */

#include "ModelLoader.hpp"

namespace small3d {


  ModelLoader::ModelLoader()
  {

  }

  ModelLoader::~ModelLoader()
  {

  }

  void ModelLoader::load( const string &filename, Model &model )
  {

  }

}
